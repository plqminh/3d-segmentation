"""
ModelSplitter - Operators Package
"""
