"""
ModelSplitter - User Interface Package
"""
